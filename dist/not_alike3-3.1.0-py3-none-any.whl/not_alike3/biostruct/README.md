# datastr-bio
DNA/RNA/Protein sequence data structure version 3.0.0 (refactored code)

```
#Instructions for testing code.
#Download repo
cd datastr
make build
./test seq.fas out.fas
```
