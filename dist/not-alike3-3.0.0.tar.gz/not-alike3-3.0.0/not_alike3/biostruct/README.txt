
Instructions to build libdnah.so

Download package, unzip it, go into the unzipped folder and build as it follows.

build:
	make build

delete:
	make delete
